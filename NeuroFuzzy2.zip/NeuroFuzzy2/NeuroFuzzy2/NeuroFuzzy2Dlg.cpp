
// NeuroFuzzy2Dlg.cpp : implementation file
//

#include "stdafx.h"
#include "NeuroFuzzy2.h"
#include "NeuroFuzzy2Dlg.h"
#include "afxdialogex.h"

#include<math.h>
#include<conio.h>
#include<stdio.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CAboutDlg dialog used for App About

class CAboutDlg : public CDialogEx
{
public:
	CAboutDlg();

// Dialog Data
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialogEx(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
END_MESSAGE_MAP()


// CNeuroFuzzy2Dlg dialog

int vinputnumber=2,vrulenumber=10,learning_time=50,vmodelnumber=1;
float alpha=0.5;
int GrafCounterTemp,simx[448],simy[448];
float SETPOINT=200,SETPOINTCONT;
float yk1=0.0;

// �Neuro Fuzzy Model
#define VINPUTNUMBER 2 // Number of input to the controller
#define VRULENUMBER 20 // Number of rules
#define VIFPART VINPUTNUMBER*VRULENUMBER // Number if part membership function
#define VMODELNUMBER 1 // Model number
#define LEARNING_TIME 50 // Learning time
#define ALPHA 0.5 // Learning rate

struct vcont_param //define data structure of
  {   //model parameters after learning
   float vxl[VIFPART]; //center of gaussian membership function
   float vtl[VIFPART]; //width of gaussian membership function
   float vyl[VRULENUMBER]; //max value of membership function at THEN part
  };
struct vcont_param vparam[VMODELNUMBER];

//FUZZY INVERSE MODEL ============================
void vfuzzy_learning(int vmodel,float vu[VINPUTNUMBER],float vyf,float vy,float *verror,float *vb,float vfuzz_out[VRULENUMBER])
//vmodel : model number
//vu : input signal
//vyf : output of fuzzy model
//vy : output of identified plant
//verror : estimation error
//vfuzz_out[] : fuzzyfipation result
//vb : sumation result of fuzzyfication
{
 int vi,vj; //counter
 int k;
 int vcount;
 int inp_number;
 struct vlearn_cont_param //define data structure of temporary
 {  //controller parameters during learning
  float vlxl[VIFPART]; //center of gaussian membership function
  float vltl[VIFPART]; //width of gaussian membership function
  float vlyl[VRULENUMBER]; //max value of membership function at THEN part
 } vl_param[2];
 //transfer the global controller parameters to temporary ones
 for(vi=0;vi<VIFPART;vi++)
 {
  vl_param[0].vlxl[vi]=vparam[vmodel].vxl[vi];
  vl_param[0].vltl[vi]=vparam[vmodel].vtl[vi];
 }
 for(vi=0;vi<VRULENUMBER;vi++)
 {
  vl_param[0].vlyl[vi]=vparam[vmodel].vyl[vi];
 }

//learning process ---------------- ��
//error calculation between actual plant signal and model
*verror=vyf-vy;
//Attention : This is different with original version as seen on WANGTRA2.
//CPP, because the model is different.
//for THEN part parameters yl, see eq. 3.4 pp. 30

for(vi=0;vi<VRULENUMBER;vi++)
vl_param[1].vlyl[vi]=vl_param[0].vlyl[vi]-(ALPHA*vfuzz_out[vi]*(*verror)/(*vb));
//for membership function parameters
//for xl, see eq. 3.7 pp. 31
//for tl, see eq. 3.8 pp. 31
vj=0;
vcount=VINPUTNUMBER;
inp_number=0;
for(k=0;k<VINPUTNUMBER;k++)
{
 for(vi=0;vi<VRULENUMBER; vi++)
 {
// for xl
 vl_param[1].vlxl[vi+(k*VRULENUMBER)]=vl_param[0].vlxl[vi+(k*VRULENUMBER)]-((ALPHA*(*verror)/(*vb))*(vl_param[0].vlyl[vj]-vyf)*vfuzz_out[vj]*(2*(vu[inp_number]-vl_param[0].vlxl[vi+(k*VRULENUMBER)]))/pow(vl_param[0].vltl[vi+(k*VRULENUMBER)],2));

// for tl
 vl_param[1].vltl[vi+(k*VRULENUMBER)]=vl_param[0].vltl[vi+(k*VRULENUMBER)]-((ALPHA*(*verror)/(*vb))*(vl_param[0].vlyl[vj]-vyf)*vfuzz_out[vj]*(2*pow((vu[inp_number]-vl_param[0].vlxl[vi+(k*VRULENUMBER)]),2)))/(pow(vl_param[0].vltl[vi+(k*VRULENUMBER)],3));

 inp_number++;
 if(inp_number==VINPUTNUMBER)
  {
   inp_number=0;
  }
 vcount--;
 if (vcount==0)
  {
   vj++;
   vcount=VINPUTNUMBER;
  }
}
}
//tranfer from controller parameters temporary variable to the global ones
for(k=0;k<VINPUTNUMBER;k++)
 {
  for(vi=0;vi<VRULENUMBER;vi++)
  {
   vparam[vmodel].vxl[vi+(k*VRULENUMBER)]=vl_param[1].vlxl[vi+(k*VRULENUMBER)];
   vparam[vmodel].vtl[vi+(k*VRULENUMBER)]=vl_param[1].vltl[vi+(k*VRULENUMBER)];
   if(k==0)
   vparam[vmodel].vyl[vi]=vl_param[1].vlyl[vi];
  }
 }
}
//end of inverse fuzzy learning


// Fuzzyfication process
void vfuzzyfication(int vmodel,float vin_signal[VINPUTNUMBER],float vfuzz_out[VRULENUMBER])
// vinzsignal zinput signal from plant
// vfuzz_out :fuzzyfication result
{
 int vi,vj; // looping counter
 int vcount; // membership function counter
 vcount=0; // init counter
 for(vi=0;vi<VRULENUMBER;vi++) {
  vfuzz_out[vi]=1; // initialization of fuzzyfication result
 for(vj=0;vj<VINPUTNUMBER;vj++) {
  vfuzz_out[vi]*= exp(-pow(((vin_signal[vj]-vparam[vmodel].vxl[vcount])/vparam[vmodel].vtl[vcount]),2));
 vcount++;
  }
 }
}
// end of fuzzyfication process

// Inference Engine
void vinf_engine(int vmodel,float vfuzz_out[VRULENUMBER],float *vinf_out)
// vfuzz_out : fuzzyfication result
// vinfmcut : inference process result
{
 int vi; //counter
 *vinf_out=0; //initialization of inference engine result
 for(vi=0;vi<VRULENUMBER;vi++) {
  *vinf_out+=vparam[vmodel].vyl[vi]*vfuzz_out[vi];
 }
}
// end of inference process

// Defuzzyfication process
void vdefuzzy(float *vinf_out, float vfuzz_out[VRULENUMBER],float *vdef_out,float *vb)
// vfuzz_out : fuzzyfication results
// vinf_put : inference result
// vdef_out : defuzzyfication result
// vb : summation result of fuzzyfication
{
 int vi; //counter
 *vb=0; //initialization of summation result

 for(vi=0;vi<VRULENUMBER;vi++) {
 *vb+=vfuzz_out[vi];
 }
 *vdef_out=*vinf_out/(*vb);
}
// end of defuzzyfication process

// Wang fuzzy inverse model

void vwangfuzzy(int vmodel,float vin_signal[VINPUTNUMBER],float vfuzz_out[VRULENUMBER],float *vcon_signal,float *vb)

// Fuzzy controller algorithm ������������������������������������������� --
// Based on Wang's 3�layers network architechture
// Membership function : Gaussian
// Inference Engine : Product�inference rule
// Defuzzifier : Center Average
// (see equation 2.46, pp. 25)
// -------------------------------------------------------------------------
//
// Controller parameters i.e.
// vyl : point in which membership function of consequence parts
// achieves its maximum value
// vxl : Gaussian membership function parameter
// vtl : Gaussian membership function parameter
// vin_signal: input signal to the controller
// vfuzz_out : fuzzyfication result
// vcon_signal: control signal from the controller
// vb : summation result of fuzzyfication
// ---------------------------------------------------------------------- --

{ // Beginning of Wang's controller
 float vinf_out; // inference engine result
 float vdef_out; // deffuzyfication result
 float vi; //sumation result of fuzzyfication

 vfuzzyfication(vmodel,vin_signal,vfuzz_out);
 vinf_engine(vmodel,vfuzz_out,&vinf_out);
 vdefuzzy(&vinf_out,vfuzz_out,&vdef_out,&vi);
 *vcon_signal=vdef_out;
 *vb=vi; //transfer the result to out of the function
} // End of Wang's fuzzy adaptive controller


// end of WANG's adaptive neuro�fuzzy inverse model

  float vfuzz_out[VRULENUMBER];
  float in_signal[VINPUTNUMBER];
  float vb;
  float fk; //output from neurofuzzy model
  float verror;

  float uk=0.0,yk=0.0,yk_1=0.0; //output of plant in k+1,k, and k�1 respectively
  float ukcont,inccont,yk1cont;
  float err,err_1,derr,sel,ser;
  int count; 
  int i,x,y,swt=0,run=0,learn=0,init=0;
  float inc; 
  char str[25];

  //int vrulenumber=10,learning_time=200,vmodelnumber=1;
  //float alpha=0.5;
  //unsigned int tc,tb;
  int xinput=0;
  


CNeuroFuzzy2Dlg::CNeuroFuzzy2Dlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(CNeuroFuzzy2Dlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_setpoint = 30;
	m_rule = 20;
	m_time = 50;
	m_rate = 0.5f;
	m_output = 10.0f;
	//  m_error = _T("");
	//  m_INC = 0;
	m_control = 0;
	m_error = 0;
	//  m_inc = 0;
	m_inc = 5.0f;
}

void CNeuroFuzzy2Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_BUTTON1, m_init);
	DDX_Control(pDX, IDC_BUTTON2, m_training);
	DDX_Control(pDX, IDC_BUTTON3, m_run);
	DDX_Control(pDX, IDC_PIC, m_pic);
	DDX_Text(pDX, IDC_EDIT1, m_setpoint);
	DDV_MinMaxInt(pDX, m_setpoint, 0, 1000);
	DDX_Text(pDX, IDC_EDIT2, m_rule);
	DDV_MinMaxInt(pDX, m_rule, 0, 100);
	DDX_Text(pDX, IDC_EDIT3, m_time);
	DDV_MinMaxInt(pDX, m_time, 0, 1000);
	DDX_Text(pDX, IDC_EDIT4, m_rate);
	DDV_MinMaxFloat(pDX, m_rate, 0, 1);
	DDX_Text(pDX, IDC_OUTPUT, m_output);
	DDV_MinMaxFloat(pDX, m_output, 0, 100);
	//  DDX_Text(pDX, IDC_ERROR, m_error);
	//  DDX_Text(pDX, IDC_ERROR, m_error);
	//  D//  DX_Text(p//  DX, I//  DC_INC, m_INC);
	//  DDV_MinMaxInt(pDX, m_INC, 0, 100);
	DDX_Text(pDX, IDC_Control, m_control);
	DDV_MinMaxInt(pDX, m_control, 0, 100);
	DDX_Text(pDX, IDC_ERROR, m_error);
	DDV_MinMaxInt(pDX, m_error, 0, 100);
	//  D//  DX_Text(p//  DX, I//  DC_INC, m_inc);
	//  DDV_MinMaxInt(pDX, m_inc, 0, 100);
	//  DDX_Control(pDX, IDC_INC, m_inc);
	//  D//  DX_Text(p//  DX, I//  DC_INC, m_inc);
	//  DDV_MinMaxInt(pDX, m_inc, 0, 100);
	DDX_Text(pDX, IDC_INC, m_inc);
	DDV_MinMaxFloat(pDX, m_inc, 0, 100);
}

BEGIN_MESSAGE_MAP(CNeuroFuzzy2Dlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON1, &CNeuroFuzzy2Dlg::OnBnClickedButton1)
	ON_BN_CLICKED(IDC_BUTTON6, &CNeuroFuzzy2Dlg::OnBnClickedButton6)
	ON_BN_CLICKED(IDC_BUTTON7, &CNeuroFuzzy2Dlg::OnBnClickedButton7)
	ON_BN_CLICKED(IDC_BUTTON5, &CNeuroFuzzy2Dlg::OnBnClickedButton5)
	ON_BN_CLICKED(IDC_BUTTON4, &CNeuroFuzzy2Dlg::OnBnClickedButton4)
	ON_BN_CLICKED(IDC_BUTTON2, &CNeuroFuzzy2Dlg::OnBnClickedButton2)
	ON_BN_CLICKED(IDC_BUTTON3, &CNeuroFuzzy2Dlg::OnBnClickedButton3)
END_MESSAGE_MAP()


// CNeuroFuzzy2Dlg message handlers

BOOL CNeuroFuzzy2Dlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// TODO: Add extra initialization here
	inc=m_inc;
	

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CNeuroFuzzy2Dlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialogEx::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CNeuroFuzzy2Dlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);

	}
	else
	{
		int i;
		CDC* pDC = m_pic.GetDC();
		for(i=0;i<100;i++){
		  pDC->MoveTo(0,300-i*3);
		  pDC->LineTo(5,300-i*3);
		}
		CDialogEx::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CNeuroFuzzy2Dlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

int setPoint=0;
int vrule;
int icount=0;
int learntime=0;

void CNeuroFuzzy2Dlg::OnBnClickedButton1()
{
	// TODO: Add your control notification handler code here
	//MessageBox(CString("test"),NULL,MB_OK);
	CDC* pDC = m_pic.GetDC();
	xinput=0;yk_1=0;
	setPoint=GetDlgItemInt(IDC_EDIT1);
	vrule=GetDlgItemInt(IDC_EDIT2);
	pDC->MoveTo(0,300-setPoint*3);
	pDC->LineTo(600,300-setPoint*3);
	init=1;
	icount=0;
}


void CNeuroFuzzy2Dlg::OnBnClickedButton6()
{
	// TODO: Add your control notification handler code here
	if((init==1)&&(icount<vrule)){
		count=0;
		uk=uk+inc;
		yk1=yk*yk_1*(yk+2.5)/(1+pow(yk,2)+pow(yk_1,2))+uk;
		err=setPoint-yk1;
		derr=err-err_1;
	
		vparam[0].vxl[count]=derr;
		vparam[0].vxl[count+vrule]=derr;
		count++;
		vparam[0].vxl[count]=err;
		vparam[0].vxl[count+vrule]=err;
	
		vparam[0].vyl[icount]=uk;

		vparam[0].vtl[icount]=0.05;
		vparam[0].vtl[icount+vrule]=0.05;
		
		SetDlgItemInt(IDC_OUTPUT,yk1);
		SetDlgItemInt(IDC_ERROR,err);

		CDC* pDC = m_pic.GetDC();
		pDC->MoveTo(xinput,300-yk*3);
		xinput=xinput+5;
		pDC->LineTo(xinput,300-yk1*3);
		yk_1=yk;
		yk=yk1;
		icount++;
	}
	if((learn==1)&&(icount<learntime)){
		uk=uk+inc;
		//uk=fk;
		yk1=yk*yk_1*(yk+2.5)/(1+pow(yk,2)+pow(yk_1,2))+uk;
		err=setPoint-yk1;
		derr=err-err_1;

		//perhitungan sinyal yang keluar dari sistem logika fuzzy 
		in_signal[0]=derr;
		in_signal[1]=err;
		vwangfuzzy(0,in_signal,vfuzz_out,&fk,&vb);

		//Proses pembelajaran
		vfuzzy_learning(0,in_signal,fk,uk,&verror,&vb,vfuzz_out);
		
		SetDlgItemInt(IDC_OUTPUT,yk1);
		SetDlgItemInt(IDC_ERROR,err);

		CDC* pDC = m_pic.GetDC();
		pDC->MoveTo(xinput,300-yk*3);
		xinput=xinput+5;
		pDC->LineTo(xinput,300-yk1*3);

		//Penyimpanan data yang lalu
		yk_1=yk;
		yk=yk1;
		err_1=err;

		icount++;
	}
	
}


void CNeuroFuzzy2Dlg::OnBnClickedButton7()
{
	// TODO: Add your control notification handler code here
	if((init==1)&&(icount<vrule)){
		count=0;
		uk=uk-inc;
		yk1=yk*yk_1*(yk+2.5)/(1+pow(yk,2)+pow(yk_1,2))+uk;
		err=setPoint-yk1;
		derr=err-err_1;
	
		vparam[0].vxl[count]=derr;
		vparam[0].vxl[count+vrule]=derr;
		count++;
		vparam[0].vxl[count]=err;
		vparam[0].vxl[count+vrule]=err;
	
		vparam[0].vyl[icount]=uk;

		vparam[0].vtl[icount]=0.05;
		vparam[0].vtl[icount+vrule]=0.05;
		
		SetDlgItemInt(IDC_OUTPUT,yk1);
		SetDlgItemInt(IDC_ERROR,err);

		CDC* pDC = m_pic.GetDC();
		pDC->MoveTo(xinput,300-yk*3);
		xinput=xinput+5;
		pDC->LineTo(xinput,300-yk1*3);
		yk_1=yk;
		yk=yk1;
		icount++;
	}
	if((learn==1)&&(icount<learntime)){
		uk=uk-inc;
		//uk=fk;
		yk1=yk*yk_1*(yk+2.5)/(1+pow(yk,2)+pow(yk_1,2))+uk;
		err=setPoint-yk1;
		derr=err-err_1;

		//perhitungan sinyal yang keluar dari sistem logika fuzzy 
		in_signal[0]=derr;
		in_signal[1]=err;
		vwangfuzzy(0,in_signal,vfuzz_out,&fk,&vb);

		//Proses pembelajaran
		vfuzzy_learning(0,in_signal,fk,uk,&verror,&vb,vfuzz_out);

		SetDlgItemInt(IDC_OUTPUT,yk1);
		SetDlgItemInt(IDC_ERROR,err);

		CDC* pDC = m_pic.GetDC();
		pDC->MoveTo(xinput,300-yk*3);
		xinput=xinput+5;
		pDC->LineTo(xinput,300-yk1*3);

		//Penyimpanan data yang lalu
		yk_1=yk;
		yk=yk1;
		err_1=err;

		icount++;
	}
}


void CNeuroFuzzy2Dlg::OnBnClickedButton5()
{
	// TODO: Add your control notification handler code here
	inc=inc-1;
	SetDlgItemInt(IDC_INC,inc);
}


void CNeuroFuzzy2Dlg::OnBnClickedButton4()
{
	// TODO: Add your control notification handler code here
	inc=inc+1;
	SetDlgItemInt(IDC_INC,inc);
}


void CNeuroFuzzy2Dlg::OnBnClickedButton2()
{
	// TODO: Add your control notification handler code here
	learn=1;
	init=0;
	learntime=GetDlgItemInt(IDC_EDIT3);
	icount=0;
	count=0; fk=yk1;yk1=0.0;yk=0.0;yk_1=0.0;
}


void CNeuroFuzzy2Dlg::OnBnClickedButton3()
{
	// TODO: Add your control notification handler code here
	run=1;init=0;learn=0;icount=0;
	count=0; fk=yk1;yk1=0.0;yk=0.0;yk_1=0.0;
	for(icount=0;icount<learntime;icount++){
		uk=fk;
		yk1=yk*yk_1*(yk+2.5)/(1+pow(yk,2)+pow(yk_1,2))+uk;
		err=setPoint-yk1;
		derr=err-err_1;

		//perhitungan sinyal yang keluar dari sistem logika fuzzy 
		in_signal[0]=derr;
		in_signal[1]=err;
		vwangfuzzy(0,in_signal,vfuzz_out,&fk,&vb);

		CDC* pDC = m_pic.GetDC();
		pDC->MoveTo(xinput,300-yk*3);
		xinput=xinput+5;
		pDC->LineTo(xinput,300-yk1*3);

		//Penyimpanan data yang lalu
		yk_1=yk;
		yk=yk1;
		err_1=err;
		fk=yk1;
	}
}
