
// NeuroFuzzy2Dlg.h : header file
//

#pragma once


// CNeuroFuzzy2Dlg dialog
class CNeuroFuzzy2Dlg : public CDialogEx
{
// Construction
public:
	CNeuroFuzzy2Dlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	enum { IDD = IDD_NEUROFUZZY2_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedButton1();
	CButton m_init;
	CButton m_training;
	CButton m_run;
	CStatic m_pic;
	int m_setpoint;
	int m_rule;
	int m_time;
	float m_rate;
	float m_output;
	afx_msg void OnBnClickedButton6();
	afx_msg void OnBnClickedButton7();
//	CString m_error;
//	CString m_error;
	afx_msg void OnBnClickedButton5();
	afx_msg void OnBnClickedButton4();
//	int m_INC;
	int m_control;
	int m_error;
//	int m_inc;
//	CStatic m_inc;
//	int m_inc;
	float m_inc;
	afx_msg void OnBnClickedButton2();
	afx_msg void OnBnClickedButton3();
};
